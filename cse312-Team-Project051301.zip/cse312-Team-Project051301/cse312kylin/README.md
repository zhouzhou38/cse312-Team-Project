cse 312 project
